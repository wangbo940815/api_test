from comm.http_request import Http_request
import unittest,requests
from ddt import ddt,unpack,data
from comm.DO_excel import Do_excel
from comm.log_decorator import log_decorator
@ddt
class Http_test(unittest.TestCase):
    request_data=Do_excel().read_excel("request_data.xlsx")
    
    @data(*request_data)
    @log_decorator
    def test_login(self,item):
        """用unpack时，测试用例的方法中接受的参数必须跟字典的键相同"""
        res_login=Http_request(item["url"],item["method"],params=eval(item["params"])) 
        res_login=res_login.http_request()
        actull=res_login.json()["msg"]
        item["actull"]=actull
        self.assertEqual(actull,item["expect"])

        
