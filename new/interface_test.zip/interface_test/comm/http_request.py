import time,requests
from requests import sessions
class Http_request:
    def __init__(self,url,method,params=None):
        self.url=url
        self.method=method
        self.params=params
    def http_request(self,cookies=None):
        if self.method.upper()=="GET":
            res=requests.get(self.url,params=self.params,cookies=cookies)
            return res
        elif self.method.upper()=="POST":
            res=requests.post(self.url,params=self.params,cookies=cookies)
            return res
        else :
            print("你输入的请求方法有误，请输入post或者get")
            return None

        